GigSure AI — PayPal AI Hackathon Submission
============================================

Builder: Ahmad Muhammad Wammi (0xFlux4hm)
Location: Lagos, Nigeria
Live app: https://gigsure-ai.vercel.app/
GitHub: https://github.com/0xFlux4hm/gigsure-ai

Contents:
---------
1. PROJECT-STORY.md     — Full project story + architecture + demo script
2. DEMO-SCRIPT.md        — 3-minute demo video narration script
3. CANVA-VIDEO-SCRIPT.md — 29-second promo video script
4. gigsure-homepage-demo.mp4 — Landing page demo (3.5 MB)
5. gigsure-promo-29sec.mp4  — 29-second promo video (2.8 MB)

Tech used:
----------
- PayPal: Orders API v2, OAuth, Webhook verification, Refunds, Sandbox
- AI: Groq (openai/gpt-oss-20b) — 500+ tok/s LPU, 5 AI features
- Next.js 16, Prisma, PostgreSQL, Tailwind CSS v4, Vercel
- Monnify + OPay (NGN payouts), Smile ID (KYC)

Prize categories:
-----------------
- Best Use of PayPal + AI
- Best Use of Agentic Commerce
- Most Impactful

"Built for Africa, starting with Nigeria."
